<?php

namespace App\Http\Controllers\Api\AppV1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Classes\Helper;
// Models
use App\Models\GlobalModel;
use App\Models\ApiModel;

class CartController extends Controller
{
    public function __construct(GlobalModel $model, ApiModel $apimodel)
    {
        $this->model = $model;
        $this->apimodel = $apimodel;
    }

    // Verify Cart
    // Developer: ShreyasM, Working Date: 9oct2024
    public function verify_cart(Request $r)
    {

        $rules = [
            'cart_json'                              => 'required|array',
            'cart_json.products'                     => 'required|array|min:1',
            'cart_json.products.*.id'                => 'required|string|max:255',
            'cart_json.products.*.customerCode'      => 'nullable|string|max:255',
            'cart_json.products.*.cashierCode'       => 'nullable|string|max:255',
            'cart_json.products.*.productCode'       => 'required|string|max:255',
            'cart_json.products.*.productName'       => 'required|string|max:255',
            'cart_json.products.*.productType'       => 'required|string|max:255',
            'cart_json.products.*.config'            => 'nullable|array',
            'cart_json.products.*.quantity'          => 'required|integer|min:1',
            'cart_json.products.*.price'             => 'required|numeric|min:0',
            'cart_json.products.*.amount'            => 'required|numeric|min:0',
            'cart_json.products.*.taxPer'            => 'nullable|numeric|min:0',
            'cart_json.products.*.pizzaSize'         => 'nullable|string|max:50',
            'cart_json.products.*.comments'          => 'nullable|string|max:255',
            'cart_json.subTotal'                     => 'required|numeric|min:0',
            'cart_json.discountAmount'               => 'nullable|numeric|min:0',
            'cart_json.taxPer'                       => 'nullable|numeric|min:0',
            'cart_json.taxAmount'                    => 'nullable|numeric|min:0',
            'cart_json.deliveryCharges'              => 'nullable|numeric|min:0',
            'cart_json.extraDeliveryCharges'         => 'nullable|numeric|min:0',
            'cart_json.grandTotal'                   => 'required|numeric|min:0',
        ];
        $messages = [
            'cart_json.required' => 'The cart data is required.',
            'cart_json.array' => 'The cart data must be an array.',

            'cart_json.products.required' => 'The products are required.',
            'cart_json.products.array' => 'The products must be an array.',
            'cart_json.products.min' => 'At least one product is required in the cart.',

            'cart_json.products.*.id.required' => 'The product ID is required.',
            'cart_json.products.*.id.string' => 'The product ID must be a string.',
            'cart_json.products.*.id.max' => 'The product ID may not be greater than 255 characters.',

            'cart_json.products.*.customerCode.string' => 'The customer code must be a string.',
            'cart_json.products.*.customerCode.max' => 'The customer code may not be greater than 255 characters.',

            'cart_json.products.*.cashierCode.string' => 'The cashier code must be a string.',
            'cart_json.products.*.cashierCode.max' => 'The cashier code may not be greater than 255 characters.',

            'cart_json.products.*.productCode.required' => 'The product code is required.',
            'cart_json.products.*.productCode.string' => 'The product code must be a string.',
            'cart_json.products.*.productCode.max' => 'The product code may not be greater than 255 characters.',

            'cart_json.products.*.productName.required' => 'The product name is required.',
            'cart_json.products.*.productName.string' => 'The product name must be a string.',
            'cart_json.products.*.productName.max' => 'The product name may not be greater than 255 characters.',

            'cart_json.products.*.productType.required' => 'The product type is required.',
            'cart_json.products.*.productType.string' => 'The product type must be a string.',
            'cart_json.products.*.productType.max' => 'The product type may not be greater than 255 characters.',

            'cart_json.products.*.config.array' => 'The config must be an array.',

            'cart_json.products.*.quantity.required' => 'The quantity is required.',
            'cart_json.products.*.quantity.integer' => 'The quantity must be an integer.',
            'cart_json.products.*.quantity.min' => 'The quantity must be at least 1.',

            'cart_json.products.*.price.required' => 'The price is required.',
            'cart_json.products.*.price.numeric' => 'The price must be a number.',
            'cart_json.products.*.price.min' => 'The price must be at least 0.',

            'cart_json.products.*.amount.required' => 'The amount is required.',
            'cart_json.products.*.amount.numeric' => 'The amount must be a number.',
            'cart_json.products.*.amount.min' => 'The amount must be at least 0.',

            'cart_json.products.*.taxPer.numeric' => 'The tax percentage must be a number.',
            'cart_json.products.*.taxPer.min' => 'The tax percentage must be at least 0.',

            'cart_json.products.*.pizzaSize.string' => 'The pizza size must be a string.',
            'cart_json.products.*.pizzaSize.max' => 'The pizza size may not be greater than 50 characters.',

            'cart_json.products.*.comments.string' => 'The comments must be a string.',
            'cart_json.products.*.comments.max' => 'The comments may not be greater than 255 characters.',

            'cart_json.subTotal.required' => 'The subtotal is required.',
            'cart_json.subTotal.numeric' => 'The subtotal must be a number.',
            'cart_json.subTotal.min' => 'The subtotal must be at least 0.',

            'cart_json.discountAmount.numeric' => 'The discount amount must be a number.',
            'cart_json.discountAmount.min' => 'The discount amount must be at least 0.',

            'cart_json.taxPer.numeric' => 'The tax percentage must be a number.',
            'cart_json.taxPer.min' => 'The tax percentage must be at least 0.',

            'cart_json.taxAmount.numeric' => 'The tax amount must be a number.',
            'cart_json.taxAmount.min' => 'The tax amount must be at least 0.',

            'cart_json.deliveryCharges.numeric' => 'The delivery charges must be a number.',
            'cart_json.deliveryCharges.min' => 'The delivery charges must be at least 0.',

            'cart_json.extraDeliveryCharges.numeric' => 'The extra delivery charges must be a number.',
            'cart_json.extraDeliveryCharges.min' => 'The extra delivery charges must be at least 0.',

            'cart_json.grandTotal.required' => 'The grand total is required.',
            'cart_json.grandTotal.numeric' => 'The grand total must be a number.',
            'cart_json.grandTotal.min' => 'The grand total must be at least 0.',

        ];
        $validate = Validator::make($r->all(), $rules, $messages);
        if ($validate->fails()) {
            return response()->json(['status' => 500, 'message' => $validate->errors()->first()], 200);
        }

        $helper = new Helper();
        $verify_sub_total = 0;
        foreach ($r->cart_json['products'] as $product) {
            $dipsAmount = 0;
            $drinksAmount = 0;
            if ($product['productType'] == "dips") {
                $dipsAmount = $helper->dips_calculations($product);
                $verify_sub_total += $dipsAmount;
            }
            if ($product['productType'] == "drinks") {
                $drinksAmount = $helper->drinks_calculations($product);
                $verify_sub_total += $drinksAmount;
            }
            if ($product['productType'] == "side") {
                $sidesAmount = $helper->sides_calculations($product);
                $verify_sub_total += $sidesAmount;
            }
            if ($product['productType'] == "custom_pizza") {
                $custompizzaAmount = $helper->custom_pizza_calculations($product);
                // dd($custompizzaAmount);
                $verify_sub_total += $custompizzaAmount;
            }
            if ($product['productType'] == "special_pizza") {
                $custompizzaAmount = $helper->special_pizza_calculations($product);
                // dd($custompizzaAmount);
                $verify_sub_total += $custompizzaAmount;
            }
        }
        $data = $helper->grand_total_calculations($verify_sub_total, $r->cart_json);
        return response()->json(['status' => 200, 'msg' => 'success', 'data' => $data], 200);
    }







    // public function get_cart($id, $device_id)
    // {
    //     try {
    //         $cart = Cart::where('id', $id)->where('device_id', $device_id)->first();
    //         $data = [];
    //         if ($cart) {
    //             $data['id'] = $cart->id;
    //             $data['device_id'] = $cart->device_id;
    //             $data['cart_json'] = json_decode($cart->cart_json);
    //             return response()->json(['status' => 200, 'message' => 'Cart found', 'data' => $data], 200);
    //         } else {
    //             return response()->json(['status' => 300, 'message' => 'Cart not found', 'data' => []], 200);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 400, 'message' => $e->getMessage()], 400);
    //     }
    // }
    // // Store a new cart
    // public function store(Request $request)
    // {
    //     try {
    //         $rules = [
    //             'device_id'                             => 'required|string|max:255',
    //             'cart_json'                             => 'required',
    //             'cart_json.products'                     => 'required|array|min:1',
    //             'cart_json.products.*.id'                => 'required',
    //             'cart_json.products.*.productCode'       => 'required',
    //             'cart_json.products.*.productName'       => 'required',
    //             'cart_json.products.*.productType'       => 'required',
    //             'cart_json.products.*.quantity'          => 'required',
    //             'cart_json.products.*.price'             => 'required',
    //             'cart_json.products.*.amount'            => 'required',
    //             'cart_json.subTotal'                    => 'required',
    //             'cart_json.discountAmount'              => 'nullable',
    //             'cart_json.taxPer'                      => 'nullable',
    //             'cart_json.taxAmount'                   => 'nullable',
    //             'cart_json.deliveryCharges'             => 'nullable',
    //             'cart_json.extraDeliveryCharges'        => 'nullable',
    //             'cart_json.grandTotal'                  => 'required',
    //         ];
    //         $messages = [
    //             'device_id.required'                         => 'The device ID is required.',
    //             'device_id.string'                           => 'The device ID must be a string.',
    //             'device_id.max'                              => 'The device ID may not be greater than 255 characters.',

    //             'cart_json.required'                         => 'The cart details are required.',
    //             'cart_json.products.required'                 => 'At least one product is required in the cart.',
    //             'cart_json.products.array'                    => 'The cart must contain an array of products.',
    //             'cart_json.products.min'                      => 'The cart must contain at least one product.',

    //             'cart_json.products.*.id.required'            => 'Each product must have an ID.',
    //             'cart_json.products.*.productCode.required'   => 'Each product must have a product code.',
    //             'cart_json.products.*.productName.required'   => 'Each product must have a product name.',
    //             'cart_json.products.*.productType.required'   => 'Each product must have a product type.',
    //             'cart_json.products.*.quantity.required'      => 'Each product must have a quantity.',
    //             'cart_json.products.*.price.required'         => 'Each product must have a price.',
    //             'cart_json.products.*.amount.required'        => 'Each product must have an amount.',

    //             'cart_json.subTotal.required'                => 'The subtotal is required.',
    //             'cart_json.discountAmount.nullable'          => 'The discount amount is optional.',
    //             'cart_json.taxPer.nullable'                  => 'The tax percentage is optional.',
    //             'cart_json.taxAmount.nullable'               => 'The tax amount is optional.',
    //             'cart_json.deliveryCharges.nullable'         => 'The delivery charges are optional.',
    //             'cart_json.extraDeliveryCharges.nullable'    => 'The extra delivery charges are optional.',
    //             'cart_json.grandTotal.required'              => 'The grand total is required.',
    //         ];

    //         $validate = Validator::make($request->all(), $rules, $messages);
    //         if ($validate->fails()) {
    //             return response()->json(['status' => 500, 'message' => $validate->errors()->first()], 200);
    //         }
    //         $data = [];
    //         $data['device_id'] = $request->device_id;
    //         $data['cart_json'] = json_encode($request->cart_json);
    //         $cart = Cart::create($data);
    //         return response()->json(['status' => 200, 'message' => 'Cart saved successfully.'], 200);
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 400, 'message' => $e->getMessage()], 400);
    //     }
    // }
    // // Update an existing cart
    // public function update(Request $request)
    // {
    //     try {
    //         $rules = [
    //             'id' => 'required|exists:cart,id',
    //             'device_id' => 'required|string|max:255',
    //             'cart_json'                             => 'required',
    //             'cart_json.products'                     => 'required|array|min:1',
    //             'cart_json.products.*.id'                => 'required',
    //             'cart_json.products.*.productCode'       => 'required',
    //             'cart_json.products.*.productName'       => 'required',
    //             'cart_json.products.*.productType'       => 'required',
    //             'cart_json.products.*.quantity'          => 'required',
    //             'cart_json.products.*.price'             => 'required',
    //             'cart_json.products.*.amount'            => 'required',
    //             'cart_json.subTotal'                    => 'required',
    //             'cart_json.discountAmount'              => 'nullable',
    //             'cart_json.taxPer'                      => 'nullable',
    //             'cart_json.taxAmount'                   => 'nullable',
    //             'cart_json.deliveryCharges'             => 'nullable',
    //             'cart_json.extraDeliveryCharges'        => 'nullable',
    //             'cart_json.grandTotal'                  => 'required',
    //         ];
    //         $messages = [
    //             'device_id.required'                         => 'The device ID is required.',
    //             'device_id.string'                           => 'The device ID must be a string.',
    //             'device_id.max'                              => 'The device ID may not be greater than 255 characters.',

    //             'cart_json.required'                         => 'The cart details are required.',
    //             'cart_json.products.required'                 => 'At least one product is required in the cart.',
    //             'cart_json.products.array'                    => 'The cart must contain an array of products.',
    //             'cart_json.products.min'                      => 'The cart must contain at least one product.',

    //             'cart_json.products.*.id.required'            => 'Each product must have an ID.',
    //             'cart_json.products.*.productCode.required'   => 'Each product must have a product code.',
    //             'cart_json.products.*.productName.required'   => 'Each product must have a product name.',
    //             'cart_json.products.*.productType.required'   => 'Each product must have a product type.',
    //             'cart_json.products.*.quantity.required'      => 'Each product must have a quantity.',
    //             'cart_json.products.*.price.required'         => 'Each product must have a price.',
    //             'cart_json.products.*.amount.required'        => 'Each product must have an amount.',

    //             'cart_json.subTotal.required'                => 'The subtotal is required.',
    //             'cart_json.discountAmount.nullable'          => 'The discount amount is optional.',
    //             'cart_json.taxPer.nullable'                  => 'The tax percentage is optional.',
    //             'cart_json.taxAmount.nullable'               => 'The tax amount is optional.',
    //             'cart_json.deliveryCharges.nullable'         => 'The delivery charges are optional.',
    //             'cart_json.extraDeliveryCharges.nullable'    => 'The extra delivery charges are optional.',
    //             'cart_json.grandTotal.required'              => 'The grand total is required.',
    //         ];
    //         $validate = Validator::make($request->all(), $rules, $messages);
    //         if ($validate->fails()) {
    //             return response()->json(['status' => 500, 'message' => $validate->errors()->first()], 200);
    //         }
    //         $cart = Cart::where('id', $request->id)->where('device_id', $request->device_id)->first();
    //         if ($cart) {
    //             $data = [];
    //             $data['cart_json'] = json_encode($request->cart_json);
    //             $cart->update($data);
    //             return response()->json(['status' => 200, 'message' => 'Cart updated successfully.'], 200);
    //         } else {
    //             return response()->json(['status' => 300, 'message' => 'Cart not found'], 200);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 400, 'message' => $e->getMessage()], 400);
    //     }
    // }
    // // Delete a cart by ID
    // public function delete($id, $device_id)
    // {
    //     $cart = Cart::where('id', $id)->where('device_id', $device_id)->first();
    //     try {
    //         if ($cart) {
    //             $cart->delete();
    //             return response()->json(['status' => 200, 'message' => 'Cart deleted successfully'], 200);
    //         } else {
    //             return response()->json(['status' => 300, 'message' => 'Cart not found'], 200);
    //         }
    //     } catch (\Exception $e) {
    //         return response()->json(['status' => 400, 'message' => $e->getMessage()], 400);
    //     }
    // }
}
