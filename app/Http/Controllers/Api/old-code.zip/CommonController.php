<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\ContactUsEmail;
use App\Models\CrustType;
use Illuminate\Http\Request;
use App\Models\GlobalModel;
use App\Models\ApiModel;
use App\Models\Cheese;
use App\Models\Crust;
use App\Models\Dips;
use App\Models\Softdrinks;
use App\Models\Specialbases;
use App\Models\Toppings;
use App\Models\SidesMaster;
use App\Models\Zipcode;
use App\Models\SidelineEntries;
use App\Models\Storelocation;
use App\Models\Setting;
use App\Models\Sauce;
use App\Models\Spices;
use App\Models\Cook;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use DB;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

use function Laravel\Prompts\select;

class CommonController extends Controller
{
	public function __construct(GlobalModel $model, ApiModel $apimodel)
	{
		$this->model = $model;
		$this->apimodel = $apimodel;
	}

	public function socketLiveApiTest()
	{
		try {
			$uri = "https://ordertracking.mrsinghspizza.ca/order/onlineorder";
			$data = [
				'orderCode' => 1,
				'orderNumber' =>  '1',
				'phoneNumber' => '8983185204',
				'status' => "placed",
				'storeCode' => 'STR_1',
				'deliveryType' => 'pickup',
				"customerName" => 'NESAO TEST USER',
				"grandTotal" =>	'10.00',
				"orderFrom" => "store"
			];
			$response = Http::get($uri, $data);
			return response()->json(['url' => $uri, 'data' => $data, 'response' => $response->json()], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_cheese()
	{
		try {
			$cheeseArray = [];

			$cacheKey = 'cheese';
			if (Cache::has($cacheKey)) {
				$cheese = Cache::get($cacheKey);
			} else {
				$cheese = Cheese::where('isActive', 1)->orderBy("id", "DESC")->get();
				Cache::put($cacheKey, $cheese, 600);
			}
			if ($cheese && count($cheese) > 0) {
				foreach ($cheese as $item) {
					$data = ["cheeseCode" => $item->code, "cheeseName" => $item->cheese, "price" => $item->price];
					array_push($cheeseArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $cheeseArray], 200);
			} else {
				return response()->json(["message" => "No Data found"], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_crust()
	{
		try {
			$crustArray = [];

			$cacheKey = 'crust';
			if (Cache::has($cacheKey)) {
				$crust = Cache::get($cacheKey);
			} else {
				$crust = Crust::where('isActive', 1)->orderBy("id", "DESC")->get();
				Cache::put($cacheKey, $crust, 600);
			}

			if ($crust && count($crust) > 0) {
				foreach ($crust as $item) {
					$data = ["crustCode" => $item->code, "crustName" => $item->crust, "price" => $item->price];
					array_push($crustArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $crustArray], 200);
			} else {
				return response()->json(["message" => "No Data found"], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_dips()
	{
		try {
			$dipsArray = [];

			$cacheKey = 'dips';
			if (Cache::has($cacheKey)) {
				$dips = Cache::get($cacheKey);
			} else {
				$dips = Dips::where('isActive', 1)->orderBy("id", "DESC")->get();
				Cache::put($cacheKey, $dips, 600);
			}
			if ($dips && count($dips) > 0) {
				foreach ($dips as $item) {
					$path = "";
					if ($item->dipsImage != "" && $item->dipsImage != null) {
						$path = url("uploads/dips/" . $item->dipsImage);
					}
					$data = ["dipsCode" => $item->code, "dipsName" => $item->dips, "image" => $path, "price" => $item->price];
					array_push($dipsArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $dipsArray], 200);
			} else {
				return response()->json(["message" => "No Data found"], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_softdrinks()
	{
		try {
			$softdrinksArray = [];
			$cacheKey = 'softdrinks';
			if (Cache::has($cacheKey)) {
				$softdrinks = Cache::get($cacheKey);
			} else {
				$softdrinks = Softdrinks::where('isActive', 1)->orderBy("id", "DESC")->get();
				Cache::put($cacheKey, $softdrinks, 600);
			}
			if ($softdrinks && count($softdrinks) > 0) {
				foreach ($softdrinks as $item) {

					$typeDrinks = [];
					if ($item->code == "SFD_5") {
						$getTypeDrinks = DB::table("juice")
							->select("juice.*")
							->where("juice.isActive", 1)
							->where("juice.isDelete", 0)
							->get();
						if ($getTypeDrinks && count($getTypeDrinks) > 0) {
							foreach ($getTypeDrinks as $items) {
								array_push($typeDrinks, $items->juice);
							}
						}
					} else {
						$getTypeDrinks = DB::table("typedrinks")
							->select("typedrinks.*")
							->where("typedrinks.isActive", 1)
							->where("typedrinks.isDelete", 0)
							->get();
						if ($getTypeDrinks && count($getTypeDrinks) > 0) {
							foreach ($getTypeDrinks as $items) {
								array_push($typeDrinks, $items->drinks);
							}
						}
					}


					$path = "";
					if ($item->softDrinkImage != "" && $item->softDrinkImage != null) {
						$path = url("uploads/softdrinks/" . $item->softDrinkImage);
					}
					$data = ["softdrinkCode" => $item->code, "softDrinksName" => $item->softdrinks, "image" => $path, "price" => $item->price, "drinkType" => $typeDrinks, "drinksCount" => $item->drinksCount, "drinksType" => $item->drinksType];
					array_push($softdrinksArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $softdrinksArray], 200);
			} else {
				return response()->json(["message" => "No Data found"], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_specialbases()
	{
		try {
			$specialbasesArray = [];
			$cacheKey = 'specialbases';
			if (Cache::has($cacheKey)) {
				$specialbases = Cache::get($cacheKey);
			} else {
				$specialbases = Specialbases::where('isActive', 1)->orderBy("id", "DESC")->get();
				Cache::put($cacheKey, $softdrinks, 600);
			}
			if ($specialbases && count($specialbases) > 0) {
				foreach ($specialbases as $item) {
					$data = ["specialbaseCode" => $item->code, "specialbaseName" => $item->specialbase, "price" => $item->price];
					array_push($specialbasesArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $specialbasesArray], 200);
			} else {
				return response()->json(["message" => "No Data found"], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_storeLocation()
	{
		try {
			$storeLocationArray = [];
			$cacheKey = 'storeLocation';
			if (Cache::has($cacheKey)) {
				$storeLocation = Cache::get($cacheKey);
			} else {
				$storeLocation = Storelocation::with('province')->where('isActive', 1)->orderBy("id", "DESC")->get();
				Cache::put($cacheKey, $storeLocation, 600);
			}
			if ($storeLocation && count($storeLocation) > 0) {
				foreach ($storeLocation as $item) {
					$data = [
						"code" => $item->code,
						"storeLocation" => $item->storeLocation,
						"storeAddress" => $item->storeAddress,
						"latitude" => $item->latitude,
						"longitude" => $item->longitude,
						"province" => $item->province,
					];
					array_push($storeLocationArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $storeLocationArray], 200);
			} else {
				return response()->json(["message" => "No Data found"], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_toppings()
	{
		try {
			$toppingsArray = [];
			$countAsOne = [];
			$countAsTwo = [];
			$freeToppings = [];
			$toppingsone = Toppings::where('isActive', 1)
				->where("toppings.countAs", 1)
				->where("toppings.isPaid", 1)
				->orderBy("id", "ASC")
				->get();
			$toppingstwo = Toppings::where('isActive', 1)
				->where("toppings.countAs", 2)
				->where("toppings.isPaid", 1)
				->orderBy("id", "ASC")
				->get();
			$freeTopping = Toppings::where('isActive', 1)
				->where("toppings.isPaid", 0)
				->orderBy("id", "ASC")
				->get();
			if ($toppingsone && count($toppingsone) > 0) {
				foreach ($toppingsone as $item) {
					$path = "";
					if ($item->toppingsImage != "" && $item->toppingsImage != null) {
						$path = url("uploads/toppings/" . $item->toppingsImage);
					}
					$data = ["toppingsCode" => $item->code, "toppingsName" => $item->toppingsName, "image" => $path, "countAs" => $item->countAs, "price" => $item->price, "isPaid" => $item->isPaid];
					array_push($countAsOne, $data);
				}
			}
			if ($toppingstwo && count($toppingstwo) > 0) {
				foreach ($toppingstwo as $item) {
					$path = "";
					if ($item->toppingsImage != "" && $item->toppingsImage != null) {
						$path = url("uploads/toppings/" . $item->toppingsImage);
					}
					$data = ["toppingsCode" => $item->code, "toppingsName" => $item->toppingsName, "image" => $path, "countAs" => $item->countAs, "price" => $item->price, "isPaid" => $item->isPaid];
					array_push($countAsTwo, $data);
				}
			}

			if ($freeTopping && count($freeTopping) > 0) {
				foreach ($freeTopping as $item) {
					$path = "";
					if ($item->toppingsImage != "" && $item->toppingsImage != null) {
						$path = url("uploads/toppings/" . $item->toppingsImage);
					}
					$data = ["toppingsCode" => $item->code, "toppingsName" => $item->toppingsName, "image" => $path, "countAs" => $item->countAs, "price" => $item->price, "isPaid" => $item->isPaid];
					array_push($freeToppings, $data);
				}
			}
			$toppingsArray = ["countAsOne" => $countAsOne, "countAsTwo" => $countAsTwo, "freeToppings" => $freeToppings];
			return response()->json([
				"message" => "Data found",
				"data" => ["toppings" => $toppingsArray]
			], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}


	public function get_sides(Request $r)
	{
		try {
			$sidesArray = [];
			$validator = Validator::make($r->all(), [
				'type' => 'nullable'
			]);
			if ($validator->fails()) {
				$response = [
					"message" => $validator->errors()->first()
				];
				return response()->json($response, 500);
			}
			$sideQuery = SidesMaster::where('isActive', 1);
			if ($r->type != "") {
				$sideQuery->where("type", $r->type);
			}
			$sideQuery->orderBy("id", "DESC");
			$sides = $sideQuery->get();
			if ($sides && count($sides) > 0) {
				foreach ($sides as $item) {
					$path = "";
					if ($item->image != "" && $item->image != null) {
						$path = url("uploads/sides/" . $item->image);
					}
					$combinationArray = [];
					$sidelineEntries = SidelineEntries::where("isActive", 1)->orderBy("id", "DESC")->where("sidemasterCode", $item->code)->get();
					if ($sidelineEntries && count($sidelineEntries) > 0) {
						foreach ($sidelineEntries as $items) {
							$linedata = ["lineCode" => $items->code, "size" => $items->size, "price" => $items->price];
							array_push($combinationArray, $linedata);
						}
					}

					$sideToppingsArray = [];
					if ($item->hasToppings == 1 && $item->nooftoppings > 0) {
						$sideToppings = DB::table('sides_toppings')->where('isActive', 1)->get();
						foreach ($sideToppings as $data) {
							$toppings = ['code' => $data->code, 'toppingsName' => $data->toppingsName];
							array_push($sideToppingsArray, $toppings);
						}
					}

					$data = ["sideCode" => $item->code, "sideName" => $item->sidename, "image" => $path, "type" => $item->type, 'hasToppings' => $item->hasToppings, 'nooftoppings' => $item->nooftoppings, "combination" => $combinationArray, "sidesToppings" => $sideToppingsArray];
					array_push($sidesArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $sidesArray], 200);
			}
			return response()->json(["message" => "No Data found"], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_all_ingredients()
	{
		try {
			$cheeseArray = [];
			$crustArray = [];
			$crustTypeArray = [];
			$dipsArray = [];
			$softdrinksArray = [];
			$specialbasesArray = [];
			$toppingsArray = [];
			$countAsOne = [];
			$countAsTwo = [];
			$freeToppings = [];
			$sauce = [];
			$spices = [];
			$cooks = [];

			$cook = Cook::where('isActive', 1)->orderBy("id", "DESC")->get();
			$spicy = Spices::where('isActive', 1)->orderBy("id", "DESC")->get();
			$sauces = Sauce::where('isActive', 1)->orderBy("id", "DESC")->get();
			$cheese = Cheese::where('isActive', 1)->orderBy("id", "DESC")->get();
			$crust = Crust::where('isActive', 1)->orderBy("id", "DESC")->get();
			$crustType = CrustType::where('isActive', 1)->orderBy("id", "DESC")->get();
			$dips = Dips::where('isActive', 1)->orderBy("id", "DESC")->get();
			$softdrinks = Softdrinks::where('isActive', 1)->orderBy("id", "DESC")->get();
			$specialbases = Specialbases::where('isActive', 1)->orderBy("id", "DESC")->get();
			$toppingsone = Toppings::where('isActive', 1)
				->where("toppings.countAs", 1)
				->where("toppings.isPaid", 1)
				->orderBy("id", "ASC")
				->get();
			$toppingstwo = Toppings::where('isActive', 1)
				->where("toppings.countAs", 2)
				->where("toppings.isPaid", 1)
				->orderBy("id", "ASC")
				->get();
			$freeTopping = Toppings::where('isActive', 1)
				->where("toppings.isPaid", 0)
				->orderBy("id", "ASC")
				->get();

			if ($cook && count($cook) > 0) {
				foreach ($cook as $item) {
					$data = ["cookCode" => $item->code, "cook" => $item->cook, "isActive" => $item->isActive, "price" => $item->price];
					array_push($cooks, $data);
				}
			}

			if ($sauces && count($sauces) > 0) {
				foreach ($sauces as $item) {
					$data = ["sauceCode" => $item->code, "sauce" => $item->sauce, "price" => $item->price, "isActive" => $item->isActive];
					array_push($sauce, $data);
				}
			}
			if ($spicy && count($spicy) > 0) {

				foreach ($spicy as $item) {

					$data = ["spicyCode" => $item->code, "spicy" => $item->spicy, "price" => $item->price, "isActive" => $item->isActive];
					array_push($spices, $data);
				}
			}
			if ($cheese && count($cheese) > 0) {
				foreach ($cheese as $item) {
					$data = ["cheeseCode" => $item->code, "price" => $item->price, "cheeseName" => $item->cheese];
					array_push($cheeseArray, $data);
				}
			}
			if ($crust && count($crust) > 0) {
				foreach ($crust as $item) {
					$data = ["crustCode" => $item->code, "price" => $item->price, "crustName" => $item->crust];
					array_push($crustArray, $data);
				}
			}

			if ($crustType && count($crustType) > 0) {
				foreach ($crustType as $item) {
					$data = ["crustTypeCode" => $item->code, "price" => $item->price, "crustType" => $item->crustType];
					array_push($crustTypeArray, $data);
				}
			}

			if ($dips && count($dips) > 0) {
				foreach ($dips as $item) {
					$path = "";
					if ($item->dipsImage != "" && $item->dipsImage != null) {
						$path = url("uploads/dips/" . $item->dipsImage);
					}
					$data = ["dipsCode" => $item->code, "dipsName" => $item->dips, "image" => $path, "price" => $item->price];
					array_push($dipsArray, $data);
				}
			}
			if ($softdrinks && count($softdrinks) > 0) {
				foreach ($softdrinks as $item) {
					$typeDrinks = [];
					if ($item->code == "SFD_5") {
						$getTypeDrinks = DB::table("juice")
							->select("juice.*")
							->where("juice.isActive", 1)
							->where("juice.isDelete", 0)
							->get();
						if ($getTypeDrinks && count($getTypeDrinks) > 0) {
							foreach ($getTypeDrinks as $items) {
								array_push($typeDrinks, $items->juice);
							}
						}
					} else {
						$getTypeDrinks = DB::table("typedrinks")
							->select("typedrinks.*")
							->where("typedrinks.isActive", 1)
							->where("typedrinks.isDelete", 0)
							->get();
						if ($getTypeDrinks && count($getTypeDrinks) > 0) {
							foreach ($getTypeDrinks as $items) {
								array_push($typeDrinks, $items->drinks);
							}
						}
					}

					$path = "";
					if ($item->softDrinkImage != "" && $item->softDrinkImage != null) {
						$path = url("uploads/softdrinks/" . $item->softDrinkImage);
					}
					$data = ["softdrinkCode" => $item->code, "softDrinksName" => $item->softdrinks, "image" => $path, "price" => $item->price, "drinkType" => $typeDrinks];
					array_push($softdrinksArray, $data);
				}
			}
			if ($specialbases && count($specialbases) > 0) {
				foreach ($specialbases as $item) {
					$data = ["specialbaseCode" => $item->code, "specialbaseName" => $item->specialbase, "price" => $item->price];
					array_push($specialbasesArray, $data);
				}
			}
			if ($toppingsone && count($toppingsone) > 0) {
				foreach ($toppingsone as $item) {
					$path = "";
					if ($item->toppingsImage != "" && $item->toppingsImage != null) {
						$path = url("uploads/toppings/" . $item->toppingsImage);
					}
					$data = ["toppingsCode" => $item->code, "toppingsName" => $item->toppingsName, "image" => $path, "countAs" => $item->countAs, "price" => $item->price, "isPaid" => $item->isPaid];
					array_push($countAsOne, $data);
				}
			}
			if ($toppingstwo && count($toppingstwo) > 0) {
				foreach ($toppingstwo as $item) {
					$path = "";
					if ($item->toppingsImage != "" && $item->toppingsImage != null) {
						$path = url("uploads/toppings/" . $item->toppingsImage);
					}
					$data = ["toppingsCode" => $item->code, "toppingsName" => $item->toppingsName, "image" => $path, "countAs" => $item->countAs, "price" => $item->price, "isPaid" => $item->isPaid];
					array_push($countAsTwo, $data);
				}
			}

			if ($freeTopping && count($freeTopping) > 0) {
				foreach ($freeTopping as $item) {
					$path = "";
					if ($item->toppingsImage != "" && $item->toppingsImage != null) {
						$path = url("uploads/toppings/" . $item->toppingsImage);
					}
					$data = ["toppingsCode" => $item->code, "toppingsName" => $item->toppingsName, "image" => $path, "countAs" => $item->countAs, "price" => $item->price, "isPaid" => $item->isPaid];
					array_push($freeToppings, $data);
				}
			}
			$toppingsArray = ["countAsOne" => $countAsOne, "countAsTwo" => $countAsTwo, "freeToppings" => $freeToppings];

			return response()->json([
				"message" => "Data found",
				"data" => ["cheese" => $cheeseArray, "crust" => $crustArray, "crustType" => $crustTypeArray, "dips" => $dipsArray, "softdrinks" => $softdrinksArray, "specialbases" => $specialbasesArray, "toppings" => $toppingsArray, "spices" => $spices, "sauce" => $sauce, "cook" => $cooks]
			], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function get_settings(Request $r)
	{
		try {
			$settingArray = [];
			$setting = Setting::where('isActive', 1)->orderBy("id", "DESC")->get();
			if ($setting && count($setting) > 0) {
				foreach ($setting as $item) {
					$data = ["settingCode" => $item->code, "settingName" => $item->settingName, "settingValue" => $item->settingValue, "type" => $item->type];
					array_push($settingArray, $data);
				}
				return response()->json(["message" => "Data found", "data" => $settingArray], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function check_zipcode_deliverable(Request $r)
	{
		try {
			$input = $r->all();
			$rules = ['zipcode' => 'required|regex:/^[ABCEGHJKLMNPRSTVXY]\d[A-Z]\d[A-Z]\d$/i'];
			$messages = [
				'zipcode.required' => 'Postal Code is required',
				'zipcode.regex' => 'Enter valid postal code.',
			];
			$validator = Validator::make($input, $rules, $messages);
			if ($validator->fails()) {
				$response = [
					"message" => $validator->errors()->first()
				];
				return response()->json($response, 500);
			}
			$result = Zipcode::where('isActive', 1)->where('zipcode', $r->zipcode)->first();
			if (!empty($result)) {
				$store = Storelocation::with('province')->where('code', $result->storeCode)->first();
				if ($store) {
					return response()->json(["message" => "data found", 'deliverable' => true, 'taxRates' => $store->province], 200);
				}
			}
			return response()->json(["message" => "data not found", 'deliverable' => false], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function zipcode_deliverable_list(Request $r)
	{
		try {
			$input = $r->all();
			$validator = Validator::make($input, [
				'search' => 'nullable',
			]);
			if ($validator->fails()) {
				$response = [
					"message" => $validator->errors()->first()
				];
				return response()->json($response, 500);
			}
			$postalCode = [];
			$result = Zipcode::select("zipcode.*")->where('isActive', 1);
			if ($r->has('search') && trim($r->search) != "") {
				$result->where('zipcode.zipcode', 'like', "$r->search%"); // Developer: ShreyasM, Working: 23-12-2023
			}
			$getQuery = $result->limit(10)->get(); // Developer: ShreyasM, Working: 23-12-2023
			if ($getQuery && count($getQuery) > 0) {
				foreach ($getQuery as $items) {
					$data = ["code" => $items->code, "zipcode" => $items->zipcode];
					array_push($postalCode, $data);
				}
				return response()->json(["message" => "data found", "data" => $postalCode], 200);
			}
			return response()->json(["message" => "data not found"], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function truncate_orders(Request $r)
	{
		try {
			DB::table('ordermaster')->truncate();
			DB::table('orderlineentries')->truncate();
			return response()->json(["message" => "Data Cleared"], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	//  Developer - Shreyas Mahamuni 
	//  Working Date - 22-11-2023 
	//  This API for get pizza price 
	public function get_pizza_price()
	{
		try {
			$pizzaPrices = DB::table('pizza_price')->select('largePizzaPrice', 'extraLargePizzaPrice')->first();
			if ($pizzaPrices) {
				return response()->json(["message" => "Data found", "data" => $pizzaPrices], 200);
			}
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}

	public function sendContactUsEmail(Request $r)
	{
		try {
			$input = $r->all();
			$validator = Validator::make($input, [
				'firstName' => 'required|min:3|max:50|regex:/^[a-zA-Z\s]+$/',
				'lastName' => 'required|min:3|max:50|regex:/^[a-zA-Z\s]+$/',
				'email' => [
					'required',
					'email',
				],
				'mobileNumber' => [
					'required',
					'digits:10',
					'numeric',
				],
				'message' => [
					'required',
					'min:3',
					'max:800'
				]
			], [
				'firstName.required' => 'The first name is required.',
				'firstName.min' => 'The first name must be at least 3 characters.',
				'firstName.max' => 'The first name may not be greater than 50 characters.',
				'firstName.regex' => 'The first name may only contain letters and spaces.',
				'lastName.required' => 'The last name is required.',
				'lastName.min' => 'The last name must be at least 3 characters.',
				'lastName.max' => 'The last name may not be greater than 50 characters.',
				'lastName.regex' => 'The last name may only contain letters and spaces.',
				'email.required' => 'The email is required.',
				'email.email' => 'Please provide a valid email address.',
				'mobileNumber.required' => 'The mobile number is required.',
				'mobileNumber.digits' => 'The mobile number must be exactly 10 digits.',
				'mobileNumber.numeric' => 'The mobile number must be numeric.',
				'message.required' => 'The message is required.',
				'message.min' => 'The message must be at least 3 characters.',
				'message.max' => 'The message must be at least 800 characters.',
			]);
			if ($validator->fails()) {
				$response = [
					"message" => $validator->errors()->first()
				];
				return response()->json($response, 500);
			}
			// mrsinghpizza@hotmail.com
			Mail::to('testing.neosaoservices@gmail.com')
				->send(new ContactUsEmail($input));

			return response()->json(["message" => "Email sent successfully"], 200);
		} catch (\Exception $ex) {
			return response()->json(['message' => $ex->getMessage()], 400);
		}
	}
}
