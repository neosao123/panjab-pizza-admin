<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CrustType;
use Illuminate\Http\Request;
use App\Models\GlobalModel;
use App\Models\ApiModel;
use App\Models\Users;
use App\Models\Specialoffer;
use App\Models\Softdrinks;
use App\Models\SidesMaster;
use App\Models\SidelineEntries;
use App\Models\Crust;
use App\Models\Cheese;
use App\Models\Specialbases;
use App\Models\Sauce;
use App\Models\Spices;
use App\Models\Cook;
use App\Models\Specialofferlineentries;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use DB;
use Illuminate\Support\Facades\Config;

class SpecialOfferController extends Controller
{

  public function homePageCard(Request $r)
  {
    try {

      $homepage = $r['homePage'] ?? 0;

      $offset = $r['offSet'] ?? 0;

      $specialOfferArray = [];
      $query = Specialoffer::select("specialoffer.*")
        ->where("isActive", 1)
        ->orderByRaw('
                	CASE
						WHEN dealType = "pickupdeal" THEN 1
						WHEN dealType = "deliverydeal" THEN 2
						WHEN dealType = "otherdeal" THEN 3
                    	ELSE 4
                	END
            	')
        ->orderByRaw('
                	CASE
                    	WHEN dealType IN ("pickupdeal", "deliverydeal", "otherdeal") THEN CAST(noofToppings AS SIGNED)
                    	ELSE NULL
                	END
            	');

      if ($homepage == 1) {
        $query->orderBy('id', 'DESC')->limit(5);
      } else {
        $query->orderBy('id', 'DESC')->limit(2)->offset($offset);
      }

      $getSpecialOffer = $query->get();
      if ($getSpecialOffer && count($getSpecialOffer) > 0) {
        foreach ($getSpecialOffer as $item) {
          $path = "";
          if ($item->specialofferphoto != "" && $item->specialofferphoto != null) {
            $path = url("uploads/specialoffer/" . $item->specialofferphoto);
          }
          $data = [
            "code" => $item->code,
            "name" => $item->name,
            "subtitle" => $item->subtitle,
            "dealType" => $item->dealType,
            "description" => $item->description ?? "",
            "noofToppings" => $item->noofToppings ?? "",
            "noofPizzas" => $item->noofPizza ?? "",
            "noofDips" => $item->noofDips ?? "",
            "noofSides" => $item->noofSides ?? "",
            "largePizzaPrice" => $item->price ?? "",
            "extraLargePizzaPrice" => $item->extraLargePrice ?? "",
            "image" => $path,
            "showOnClient" => $item->showOnClient ?? 0,
          ];
          array_push($specialOfferArray, $data);
        }
        return response()->json(["message" => "Data found", "data" => $specialOfferArray], 200);
      }
    } catch (\Exception $ex) {
      return response()->json(['message' => $ex->getMessage()], 400);
    }
  }

  public function list(Request $r)
  {
    try {


      $specialOfferArray = [];
      $query = Specialoffer::select("specialoffer.*")
        ->where("isActive", 1)
        ->orderByRaw('
                	CASE
						WHEN dealType = "pickupdeal" THEN 1
						WHEN dealType = "deliverydeal" THEN 2
						WHEN dealType = "otherdeal" THEN 3
                    	ELSE 4
                	END
            	')
        ->orderByRaw('
                	CASE
                    	WHEN dealType IN ("pickupdeal", "deliverydeal", "otherdeal") THEN CAST(noofToppings AS SIGNED)
                    	ELSE NULL
                	END
            	');

      $getSpecialOffer =   $query->orderBy('id', 'DESC')->get();

      if ($getSpecialOffer && count($getSpecialOffer) > 0) {
        foreach ($getSpecialOffer as $item) {
          $path = "";
          if ($item->specialofferphoto != "" && $item->specialofferphoto != null) {
            $path = url("uploads/specialoffer/" . $item->specialofferphoto);
          }
          $data = [
            "code" => $item->code,
            "name" => $item->name,
            "subtitle" => $item->subtitle,
            "dealType" => $item->dealType,
            "description" => $item->description ?? "",
            "noofToppings" => $item->noofToppings ?? "",
            "noofPizzas" => $item->noofPizza ?? "",
            "noofDips" => $item->noofDips ?? "",
            "noofSides" => $item->noofSides ?? "",
            "largePizzaPrice" => $item->price ?? "",
            "extraLargePizzaPrice" => $item->extraLargePrice ?? "",
            "image" => $path,
            "showOnClient" => $item->showOnClient ?? 0,
          ];
          array_push($specialOfferArray, $data);
        }
        return response()->json(["message" => "Data found", "data" => $specialOfferArray], 200);
      }
    } catch (\Exception $ex) {
      return response()->json(['message' => $ex->getMessage()], 400);
    }
  }

  public function show($code)
  {
    try {

      if (!$code && $code != "") {
        $response = [
          "message" => "Invalid request"
        ];
        return response()->json($response, 500);
      }
      $getSpecialDetails = Specialoffer::select("specialoffer.*")
        ->where("specialoffer.code", $code)
        ->where("isActive", 1)
        ->first();

      if (!empty($getSpecialDetails)) {
        $popsData = [];
        $bottleData = [];
        $sideArray = [];
        $specialbasesArray = [];
        $crustArray = [];
        $crustTypeArray = [];
        $cheeseArray = [];
        $freeSideArray = [];
        $sauce = [];
        $spices = [];
        $cooks = [];

        $crust = Crust::where('isActive', 1)->orderBy("id", "DESC")->get();
        $crustType = CrustType::where('isActive', 1)->orderBy("id", "DESC")->get();
        $cheese = Cheese::where('isActive', 1)->orderBy("id", "DESC")->get();
        $specialbases = Specialbases::where('isActive', 1)->orderBy("id", "DESC")->get();
        $cook = Cook::where('isActive', 1)->orderBy("id", "DESC")->get();
        $spicy = Spices::where('isActive', 1)->orderBy("id", "DESC")->get();
        $sauces = Sauce::where('isActive', 1)->orderBy("id", "DESC")->get();
        $path = "";
        if ($getSpecialDetails->specialofferphoto != "" && $getSpecialDetails->specialofferphoto != null) {
          $path = url("uploads/specialoffer/" . $getSpecialDetails->specialofferphoto);
        }
        $type = json_decode($getSpecialDetails->type, true);

        if (!empty($type) && $type != null && $type != "") {
          $freesides = SidesMaster::select("sidemaster.*", "specialofferlineentries.sidemasterCode", "specialofferlineentries.sidelineentries")
            ->join("specialofferlineentries", "specialofferlineentries.sidemasterCode", "=", "sidemaster.code", "left")
            ->where("specialofferlineentries.specialOfferCode", $r->code)
            ->where("sidemaster.isActive", 1)
            ->where("specialofferlineentries.isActive", 1)
            ->where("specialofferlineentries.isDelete", 0)
            ->whereIn("sidemaster.type", $type)
            ->get();
          if ($freesides && count($freesides) > 0) {
            foreach ($freesides as $items) {
              $freesideLineData = [];
              $freesideImageUrl = "";
              if ($items->image != "" && $items->image != null) {
                $freesideImageUrl = url("uploads/sides/" . $items->image);
              }
              $freegetPricing = SidelineEntries::select("sidelineentries.*")
                ->join("specialofferlineentries", "specialofferlineentries.sidelineentries", "=", "sidelineentries.code", "left")
                ->where("specialofferlineentries.sidelineentries", $items->sidelineentries)
                ->first();
              if (!empty($freegetPricing)) {
                $freesideLine = ["code" => $freegetPricing->code, "size" => $freegetPricing->size, "price" => $freegetPricing->price];
                array_push($freesideLineData, $freesideLine);
              }

              $freesidedata = [
                "code" => $items->code,
                "sideName" => $items->sidename,
                "type" => $items->type,
                "image" => $freesideImageUrl,
                "lineEntries" => $freesideLineData,
              ];

              array_push($freeSideArray, $freesidedata);
            }
          }
        }

        if ($getSpecialDetails->pops != null && $getSpecialDetails->pops != "") {
          $typeDrinks = [];
          $pops = Softdrinks::select("softdrinks.*")
            ->where("code", $getSpecialDetails->pops)
            ->first();
          if (!empty($pops)) {
            $pospImage = "";
            if ($pops->softDrinkImage != "" && $pops->softDrinkImage != null) {
              $pospImage = url("uploads/softdrinks/" . $pops->softDrinkImage);
            }

            $typeDrinks = [];
            if ($pops->code == "SFD_5") {
              $getTypeDrinks = DB::table("juice")
                ->select("juice.*")
                ->where("juice.isActive", 1)
                ->where("juice.isDelete", 0)
                ->get();
              if ($getTypeDrinks && count($getTypeDrinks) > 0) {
                foreach ($getTypeDrinks as $items) {
                  array_push($typeDrinks, $items->juice);
                }
              }
            } else {
              $getTypeDrinks = DB::table("typedrinks")
                ->select("typedrinks.*")
                ->where("typedrinks.isActive", 1)
                ->where("typedrinks.isDelete", 0)
                ->get();
              if ($getTypeDrinks && count($getTypeDrinks) > 0) {
                foreach ($getTypeDrinks as $items) {
                  array_push($typeDrinks, $items->drinks);
                }
              }
            }

            $popArr = [
              'code' => $pops->code,
              'softDrinkName' => $pops->softdrinks,
              'price' => $pops->price,
              'image' => $pospImage,
              'drinkType' => $typeDrinks,
            ];

            $popsData[] = $popArr;
          }
        }
        if ($getSpecialDetails->bottle != null && $getSpecialDetails->bottle != "") {
          $typeDrinks = [];
          $bottle = Softdrinks::select("softdrinks.*")
            ->where("code", $getSpecialDetails->bottle)
            ->first();
          if (!empty($bottle)) {
            $bottleImage = "";
            if ($bottle->softDrinkImage != "" && $bottle->softDrinkImage != null) {
              $bottleImage = url("uploads/softdrinks/" . $bottle->softDrinkImage);
            }

            $getTypeDrinks = DB::table("typedrinks")
              ->select("typedrinks.*")
              ->where("typedrinks.isActive", 1)
              ->where("typedrinks.isDelete", 0)
              ->get();
            if ($getTypeDrinks && count($getTypeDrinks) > 0) {
              foreach ($getTypeDrinks as $items) {
                array_push($typeDrinks, $items->drinks);
              }
            }

            $bottleArr = [
              'code' => $bottle->code,
              'softDrinkName' => $bottle->softdrinks,
              'price' => $bottle->price,
              'image' => $bottleImage,
              'drinkType' => $typeDrinks,
            ];

            $bottleData[] = $bottleArr;
          }
        }
        if ($cheese && count($cheese) > 0) {
          foreach ($cheese as $item) {
            $cheesedata = ["code" => $item->code, "cheeseName" => $item->cheese, "price" => $item->price];
            array_push($cheeseArray, $cheesedata);
          }
        }
        if ($crust && count($crust) > 0) {
          foreach ($crust as $item) {
            $crustdata = ["code" => $item->code, "crustName" => $item->crust, "price" => $item->price];
            array_push($crustArray, $crustdata);
          }
        }

        if ($crustType && count($crustType) > 0) {
          foreach ($crustType as $item) {
            $crustTypedata = ["crustTypeCode" => $item->code, "crustType" => $item->crustType, "price" => $item->price];
            array_push($crustTypeArray, $crustTypedata);
          }
        }

        if ($specialbases && count($specialbases) > 0) {
          foreach ($specialbases as $item) {
            $specialbasesdata = ["code" => $item->code, "specialbaseName" => $item->specialbase, "price" => $item->price];
            array_push($specialbasesArray, $specialbasesdata);
          }
        }

        if ($cook && count($cook) > 0) {
          foreach ($cook as $item) {
            $data = ["cookCode" => $item->code, "cook" => $item->cook, "isActive" => $item->isActive, "price" => $item->price];
            array_push($cooks, $data);
          }
        }

        if ($sauces && count($sauces) > 0) {
          foreach ($sauces as $item) {
            $data = ["sauceCode" => $item->code, "sauce" => $item->sauce, "price" => $item->price, "isActive" => $item->isActive];
            array_push($sauce, $data);
          }
        }
        if ($spicy && count($spicy) > 0) {

          foreach ($spicy as $item) {

            $data = ["spicyCode" => $item->code, "spicy" => $item->spicy, "price" => $item->price, "isActive" => $item->isActive];
            array_push($spices, $data);
          }
        }

        $data["code"] = $getSpecialDetails->code;
        $data["name"] = $getSpecialDetails->name;
        $data["subtitle"] = $getSpecialDetails->subtitle;

        $data["description"] = $getSpecialDetails->description ?? "";
        $data["noofToppings"] = $getSpecialDetails->noofToppings ?? "";
        $data["noofDips"] = $getSpecialDetails->noofDips ?? "";
        $data["noofSides"] = $getSpecialDetails->noofSides ?? "";
        $data["noofPizzas"] = $getSpecialDetails->noofPizza ?? "";
        $data["largePizzaPrice"] = $getSpecialDetails->price ?? "";
        $data["extraLargePizzaPrice"] = $getSpecialDetails->extraLargePrice ?? "";
        $data['showOnClient'] = $getSpecialDetails->showOnClient ?? 0;

        $data['noofDrinks'] = (sizeof($bottleData) > 0 || sizeof($popsData) > 0) ? 1 : 0;

        $data["image"] = $path;
        $data["freesides"] = $freeSideArray;
        $data["sides"] = $sideArray;
        $data["pops"] = $popsData;
        $data["bottle"] = $bottleData;
        $data["cheese"] = $cheeseArray;
        $data["crust"] = $crustArray;
        $data["crustType"] = $crustTypeArray;
        $data["specialbases"] = $specialbasesArray;
        $data["cook"] = $cooks;
        $data["sauce"] = $sauce;
        $data["spices"] = $spices;


        return response()->json(["message" => "Data found", "data" => $data], 200);
      }
      return response()->json(["message" => "Data not found"], 200);
    } catch (\Exception $ex) {
      return response()->json(['message' => $ex->getMessage()], 400);
    }
  }
}
