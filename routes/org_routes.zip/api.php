<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\CommonController;
use App\Http\Controllers\Api\CashierController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\SpecialOfferController;
use App\Http\Controllers\Api\CashierOrderController;
use App\Http\Controllers\Api\InvoicesController;
use App\Http\Controllers\Api\CustomerOrderController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\StoreReportsController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::get('/socket-live-api', [CommonController::class, 'socketLiveApiTest']);
Route::get('/truncate/orders', [CommonController::class, 'truncate_orders']);
Route::get('/trial-notify', [CashierController::class, 'send_trial_notification']);
Route::group(['middleware' => 'cors'], function () {

	//Route::middleware(['auth:sanctum'])->group(function () {
	Route::get('/cheese', [CommonController::class, 'get_cheese']);
	Route::get('/settings', [CommonController::class, 'get_settings']);
	Route::get('/crust', [CommonController::class, 'get_crust']);
	Route::get('/dips', [CommonController::class, 'get_dips']);
	Route::get('/softdrinks', [CommonController::class, 'get_softdrinks']);
	Route::get('/specialbases', [CommonController::class, 'get_specialbases']);
	Route::get('/toppings', [CommonController::class, 'get_toppings']);
	Route::get('/getAllIngredients', [CommonController::class, 'get_all_ingredients']);
	Route::get('/sides', [CommonController::class, 'get_sides']);
	Route::get('/storelocation', [CommonController::class, 'get_storeLocation']);
	Route::get('/getSpecials', [SpecialOfferController::class, 'get_specials']);
	Route::post('/getSpecialDetails', [SpecialOfferController::class, 'get_specials_details']);
	Route::post('/zipcode/check/deliverable', [CommonController::class, 'check_zipcode_deliverable']);
	Route::post('/zipcode/list', [CommonController::class, 'zipcode_deliverable_list']);
	// Developer - Shreyas Mahamuni, Working Date - 22-11-2023, routes for get pizza price
	Route::get('/pizzaPrice', [CommonController::class, 'get_pizza_price']);


	Route::group(['prefix' => '/customer'], function () {
		Route::post('/logout', [CustomerController::class, 'customer_logout']);
		Route::post('/profile', [CustomerController::class, 'get_customer_info']);
		Route::get('/detailsByToken', [CustomerController::class, 'customer_details_by_token']);
		Route::post('/updateProfile', [CustomerController::class, 'update_customer_info']);
		Route::post('/addAddress', [CustomerController::class, 'add_customer_address']);
		Route::post('/updateAddress', [CustomerController::class, 'update_customer_address']);
		Route::post('/deleteAddress', [CustomerController::class, 'delete_customer_address']);
		Route::get('/getstorelocationbycity', [CustomerController::class, 'getStoreLocationByCity']);
		Route::get('/getDynamicSlider', [CustomerController::class, 'getDynamicSlider']);
		Route::get('/previousorder', [CashierOrderController::class, 'get_previous_order']);
		Route::post('/payment/callback',  [CustomerOrderController::class, 'webhook']);
		Route::get('/payment/success',  [CustomerOrderController::class, 'payment_success']);
		Route::get('/payment/failed',  [CustomerOrderController::class, 'payment_failed']);
		Route::post('/changepassword', [CustomerController::class, 'change_password']);
		//customer order api
		Route::group(['prefix' => '/order'], function () {
			Route::post('/place',  [CustomerOrderController::class, 'order_place']);
			Route::post('/list',  [CustomerOrderController::class, 'get_order_list']);
			Route::post('/details',  [CustomerOrderController::class, 'get_order_details']);
			Route::post('/getlist',  [CustomerOrderController::class, 'customer_order_list']);
		});
	});

	//cashier order  
	Route::post('/cashier/order/statuschange', [CashierOrderController::class, 'update_order_status']);
	Route::post('/cashier/order/place', [CashierOrderController::class, 'order_place']);
	Route::post('/cashier/order/edit', [CashierOrderController::class, 'order_edit']);
	Route::post('/cashier/order/details', [CashierOrderController::class, 'get_order_details']);
	Route::post('/cashier/order/assignDeliveryExecutive', [CashierOrderController::class, 'delivery_executive_assign']);
	Route::get('/delivery-executive', [CashierOrderController::class, 'get_delivery_executive_list']);
	Route::post('/cashier/order/list', [CashierOrderController::class, 'get_order_list']);
	Route::get('/deliveryExecutive/{storeCode}', [CashierOrderController::class, 'get_delivery_executive_by_storecode']);
	//});
	Route::get('/cashier/detailsByToken', [CashierController::class, 'cashier_details_by_token']);
	Route::post('/cashier/order/deliveryTypeChange', [CashierOrderController::class, 'update_delivery_type']);
	Route::post('/cashier/order/directDeliveryTypeChange', [CashierOrderController::class, 'direct_update_delivery_type']);
	Route::post('/cashier/order/notificationList', [CashierOrderController::class, 'get_notification_order_list']);
	Route::post('/cashier/order/addCreditComments', [CashierOrderController::class, 'add_credit_comments']);
	Route::get('/cashier/order/date_time', [CashierOrderController::class, 'date_time']);
	Route::get('/cashier/highlight/screen', [CashierOrderController::class, 'get_placed_or_ready_orders']);
	Route::get('/cashier/bellringer/screen', [CashierOrderController::class, 'get_orders_for_accept_screen']);
	Route::get('/cashier/store/summary', [CashierOrderController::class, 'order_summary']);

	// cashier api
	Route::group(['prefix' => '/cashier'], function () {
		Route::post('/login', [CashierController::class, 'cashier_login']);
		Route::post('/resetPassword', [CashierController::class, 'cashier_reset_password']);
		Route::get('/verifyToken', [CashierController::class, 'verify_cashier_token']);
		Route::post('/updatePassword', [CashierController::class, 'update_cashier_password']);
		Route::post('/change-password', [CashierController::class, 'change_password']);
		Route::post('/logout', [CashierController::class, 'cashier_logout']);
		Route::post('/profile', [CashierController::class, 'get_cashier_info']);
		Route::post('/updateProfile', [CashierController::class, 'update_cashier_info']);
		Route::post('/updateFirebaseId', [CashierController::class, 'update_firebase_token']);
		Route::post('/getPrevAddress', [CashierController::class, 'getPrevAddress']);
	});

	// customer api
	Route::group(['prefix' => '/customer'], function () {
		Route::post('/login', [CustomerController::class, 'customer_login']);
		Route::post('/register', [CustomerController::class, 'customer_register']);
		Route::post('/resetPassword', [CustomerController::class, 'customer_reset_password']);
		Route::get('/verifyToken', [CustomerController::class, 'verify_customer_token']);
		Route::post('/updatePassword', [CustomerController::class, 'update_customer_password']);
	});

	Route::group(['prefix' => '/payment'], function () {
		Route::post('/verify', [PaymentController::class, 'verify']);
		Route::post('/cancel', [PaymentController::class, 'cancel']);
	});

	// invoice api
	Route::group(['prefix' => '/invoice'], function () {
		Route::post('/list', [InvoicesController::class, 'getInvoice']);
	});
	Route::get('/invoices', [InvoicesController::class, 'getListByMobileNumber']);


	Route::group(['prefix' => '/storeReport'], function () {
		Route::get('/downloadReports', [StoreReportsController::class, 'downloadReports']);
		Route::get('/sendReportToEmail', [StoreReportsController::class, 'sendReportToEmail']);
	});

	Route::get('send/daily/store/summary', [StoreReportsController::class, 'daily_store_summary_mail']);

	Route::post('sendContactUsEmail', [CommonController::class, 'sendContactUsEmail']);
});
