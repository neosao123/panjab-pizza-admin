$(document).ready(function () {
  let dropArea = $("#drop-area");
  let fileInput = $("#fileInput");
  let preview = $("#preview");

  dropArea.on("click", function (e) {
    fileInput[0].click();
  });

  fileInput.on("change", function (e) {
    handleFiles(e.target.files);
  });

  dropArea.on("dragover", function (e) {
    e.preventDefault();
    e.stopPropagation();
    dropArea.addClass("dragover");
  });

  dropArea.on("dragleave", function (e) {
    e.preventDefault();
    e.stopPropagation();
    dropArea.removeClass("dragover");
  });

  dropArea.on("drop", function (e) {
    e.preventDefault();
    e.stopPropagation();
    dropArea.removeClass("dragover");
    let files = e.originalEvent.dataTransfer.files;
    fileInput[0].files = files;
    handleFiles(files);
  });

  function handleFiles(file) {
    const allowedExtensions = /\.(jpeg|jpg|png|webp)$/i;
    if (!allowedExtensions.test(file.name)) {
      // Show inline validation message
      $("#imageError").text("Invalid file type. Allowed: .jpg, .jpeg, .png, .webp");
      fileInput.val(null);
      preview.attr("src", "").addClass("d-none");
      return;
    }

    const reader = new FileReader();
    reader.onload = function (event) {
      const img = new Image();
      img.onload = function () {
        // Require exact 512x512 to match server-side validation
        if (img.width >= 512 && img.height >= 512) {
          preview.attr("src", event.target.result).removeClass("d-none");
        } else {
          // Show inline validation message for dimensions
          $("#imageError").text("The image must be exactly 512x512 pixels.");
          try {
            fileInput[0].value = "";
          } catch (e) {
            fileInput.val(null);
          }
          preview.attr("src", "").addClass("d-none");
        }
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  }
});
